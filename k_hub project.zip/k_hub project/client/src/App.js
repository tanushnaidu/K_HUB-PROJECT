import React, { useState } from 'react';
import * as XLSX from 'xlsx';
import Dropzone from 'react-dropzone';
import Plot from 'react-plotly.js';
import './App.css';
import axios from 'axios';

function App() {
  const [uploadedFile, setUploadedFile] = useState(null);
  const [filteredData, setFilteredData] = useState(null); // State to store the filtered data

  const handleFileUpload = async (acceptedFiles) => {
    const file = acceptedFiles[0];
    setUploadedFile(file);

    const reader = new FileReader();
    reader.onload = function (e) {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: 'array' });
      const firstSheet = workbook.SheetNames[0];
      const excelData = XLSX.utils.sheet_to_json(workbook.Sheets[firstSheet]);

      // Remove columns with all null values
      const filteredData = excelData.filter((item) => !Object.values(item).every((value) => value === null));

      // Set the filtered data to the state
      setFilteredData(filteredData);

      // Save the filtered data to the backend
      saveDataToBackend(filteredData);
    };
    reader.readAsArrayBuffer(file);
  };

  const saveDataToBackend = async (data) => {
    try {
      await axios.post('/api/saveData', { data });
      console.log('Data saved to MongoDB');
    } catch (error) {
      console.error('Error saving data to MongoDB:', error);
    }
  };

  const renderCharts = () => {
    if (filteredData && filteredData.length > 0) {
      const columns = Object.keys(filteredData[0]);

      // Generate data for the bar chart
      const barTraces = columns.map((column) => ({
        x: columns,
        y: filteredData.map((item) => item[column]),
        type: 'bar',
        name: column,
      }));

      // Generate data for the scatter plot
      const scatterTraces = columns.map((column) => ({
        x: filteredData.map((item) => item[column]),
        y: filteredData.map((item) => item[column]),
        mode: 'markers',
        type: 'scatter',
        name: column,
      }));

      // Data for the surface plot
      const surfaceTrace = {
        type: 'surface',
        z: filteredData.map((item) => Object.values(item).map((value) => value * 10)), // Multiply by 10 to amplify the surface plot
      };

      return (
        <>
          <div className="chart-container-flex">
            {/* Bar Chart */}
            <div className="chart-container">
              <h2>Bar Chart</h2>
              <Plot data={barTraces} layout={{ title: 'Bar Chart', barmode: 'group' }} config={{ responsive: true }} />
            </div>

            {/* Scatter Plot */}
            <div className="chart-container">
              <h2>Scatter Plot</h2>
              <Plot data={scatterTraces} layout={{ title: 'Scatter Plot' }} config={{ responsive: true }} />
            </div>

            {/* Surface Plot */}
            <div className="chart-container">
              <h2>Surface Plot</h2>
              <Plot data={[surfaceTrace]} layout={{ title: 'Surface Plot' }} config={{ responsive: true }} />
            </div>
          </div>
        </>
      );
    } else {
      return <p>Upload an Excel file to visualize</p>;
    }
  };

  return (
    <div className="container">
      <h1 className="title">K_HUB Data Visualization</h1>
      <Dropzone onDrop={handleFileUpload}>
        {({ getRootProps, getInputProps }) => (
          <div {...getRootProps()} className="dropzone">
            <input {...getInputProps()} />
            <p className="bold-text">Upload or drop an Excel file</p>
            {uploadedFile && <p className="file-info">Uploaded File: {uploadedFile.name}</p>}
          </div>
        )}
      </Dropzone>
      {renderCharts()}
    </div>
  );
}

export default App;
